import express from "express";
import * as purchasingController from "../controllers/purchasingController.js";
import { requireAuth, requireRole } from "../middleware/authMiddleware.js";

const router = express.Router();

// Suppliers
router.get("/suppliers", purchasingController.getSuppliers);
router.post("/suppliers", purchasingController.createSupplier);
router.put("/suppliers/:id", purchasingController.updateSupplier);

// Purchase Orders
router.get("/", purchasingController.getPurchaseOrders);
router.post("/", purchasingController.createPurchaseOrder);
router.put("/:id/status", purchasingController.updatePurchaseOrderStatus);

// === Supplier Portal Routes ===
// Suppliers can only see their own POs
router.get("/my-orders", requireAuth, requireRole('Supplier'), purchasingController.getSupplierOwnOrders);
// Suppliers can update the status of their own POs (Accept, Decline, To Be Delivered)
router.put("/my-orders/:id/status", requireAuth, requireRole('Supplier'), purchasingController.updateSupplierOrderStatus);

export default router;
